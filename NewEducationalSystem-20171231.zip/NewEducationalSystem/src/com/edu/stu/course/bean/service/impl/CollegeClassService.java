package com.edu.stu.course.bean.service.impl;

import org.apache.log4j.Logger;
import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.course.bean.CollegeClass;
import com.edu.stu.course.bean.mapper.CollegeClassMapper;
import com.edu.stu.course.bean.service.ICollegeClassService;

public class CollegeClassService extends JUIService<CollegeClass, CollegeClassMapper> implements ICollegeClassService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeClassService.class);

	public CollegeClassService() {
		super(MybatisMutiKit.new_education_db, CollegeClassMapper.class, CollegeClass.class);
	}

}
