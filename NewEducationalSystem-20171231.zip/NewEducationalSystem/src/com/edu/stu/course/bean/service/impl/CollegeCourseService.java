package com.edu.stu.course.bean.service.impl;

import org.apache.log4j.Logger;
import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.course.bean.CollegeCourse;
import com.edu.stu.course.bean.mapper.CollegeCourseMapper;
import com.edu.stu.course.bean.service.ICollegeCourseService;

public class CollegeCourseService extends JUIService<CollegeCourse, CollegeCourseMapper> implements ICollegeCourseService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeCourseService.class);

	public CollegeCourseService() {
		super(MybatisMutiKit.new_education_db, CollegeCourseMapper.class, CollegeCourse.class);
	}

}
