package com.edu.stu.atten.bean.mapper;

import com.edu.stu.atten.bean.AttendanceRecordHead;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface AttendanceRecordHeadMapper extends BaseSupportMapper {
}