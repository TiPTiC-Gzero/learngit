package com.edu.stu.course.bean.service.impl;

import org.apache.log4j.Logger;
import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.course.bean.CollegeMajor;
import com.edu.stu.course.bean.mapper.CollegeMajorMapper;
import com.edu.stu.course.bean.service.ICollegeMajorService;

public class CollegeMajorService extends JUIService<CollegeMajor, CollegeMajorMapper> implements ICollegeMajorService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeMajorService.class);

	public CollegeMajorService() {
		super(MybatisMutiKit.new_education_db, CollegeMajorMapper.class, CollegeMajor.class);
	}

}
