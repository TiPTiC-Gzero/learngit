/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50536
Source Host           : localhost:3306
Source Database       : new_education_db

Target Server Type    : MYSQL
Target Server Version : 50536
File Encoding         : 65001

Date: 2017-12-31 20:09:29
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `stu_attendance_record_detail`
-- ----------------------------
DROP TABLE IF EXISTS `stu_attendance_record_detail`;
CREATE TABLE `stu_attendance_record_detail` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `attDate` date NOT NULL COMMENT '考勤日期',
  `userId` varchar(50) NOT NULL COMMENT '用户id',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1上课，2下课',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime NOT NULL COMMENT '打卡时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生考勤打卡记录明细表';

-- ----------------------------
-- Records of stu_attendance_record_detail
-- ----------------------------
INSERT INTO `stu_attendance_record_detail` VALUES ('1b260ef08f9c4012915bb5dfdc91ef0b', '2017-12-31', 'b5e59bd6e1da4098a28da61121e1d39b', '1', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 17:45:49', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 17:45:49', '');
INSERT INTO `stu_attendance_record_detail` VALUES ('50d1ba1037434967a77c0e4f9e34be11', '2017-12-31', 'b5e59bd6e1da4098a28da61121e1d39b', '1', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 17:52:23', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 17:52:23', '');
INSERT INTO `stu_attendance_record_detail` VALUES ('51b1235216f645318116759c64bf5d8c', '2017-12-31', 'b5e59bd6e1da4098a28da61121e1d39b', '2', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 17:56:09', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 17:56:09', '');
INSERT INTO `stu_attendance_record_detail` VALUES ('7aa264d850354a4b97f6ede228aa7179', '2017-12-31', 'b5e59bd6e1da4098a28da61121e1d39b', '1', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 17:55:35', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 17:55:35', '');
INSERT INTO `stu_attendance_record_detail` VALUES ('fb9bf329d8c44574a6c98ad726a6a3f4', '2017-12-31', 'b5e59bd6e1da4098a28da61121e1d39b', '2', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 18:03:51', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 18:03:51', '');

-- ----------------------------
-- Table structure for `stu_attendance_record_head`
-- ----------------------------
DROP TABLE IF EXISTS `stu_attendance_record_head`;
CREATE TABLE `stu_attendance_record_head` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `attDate` date NOT NULL COMMENT '考勤日期',
  `userId` varchar(50) NOT NULL COMMENT '用户id',
  `startDate` datetime DEFAULT NULL COMMENT '上课第一次打卡时间',
  `endDate` datetime DEFAULT NULL COMMENT '下课最后一次打卡时间',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生考勤打卡记录主表';

-- ----------------------------
-- Records of stu_attendance_record_head
-- ----------------------------
INSERT INTO `stu_attendance_record_head` VALUES ('df89508db9034fd182c273fd30d06f1a', '2017-12-31', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 17:55:35', '2017-12-31 18:03:51', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 17:55:35', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 18:03:51', '');

-- ----------------------------
-- Table structure for `stu_college_class`
-- ----------------------------
DROP TABLE IF EXISTS `stu_college_class`;
CREATE TABLE `stu_college_class` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `classYear` int(5) NOT NULL COMMENT '班级学年',
  `majorId` varchar(50) NOT NULL DEFAULT '0000' COMMENT '专业id',
  `name` varchar(20) NOT NULL COMMENT '班级名称(分班)',
  `headTeacher` varchar(20) DEFAULT NULL COMMENT '班主任姓名',
  `remark` varchar(250) DEFAULT NULL COMMENT '备注',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学校班级信息管理表';

-- ----------------------------
-- Records of stu_college_class
-- ----------------------------

-- ----------------------------
-- Table structure for `stu_college_class2user`
-- ----------------------------
DROP TABLE IF EXISTS `stu_college_class2user`;
CREATE TABLE `stu_college_class2user` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `classId` varchar(50) NOT NULL COMMENT '班级id--stu_college_class.id',
  `userId` varchar(50) NOT NULL DEFAULT '' COMMENT '学生id--user.id',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='班级与学生关联表';

-- ----------------------------
-- Records of stu_college_class2user
-- ----------------------------

-- ----------------------------
-- Table structure for `stu_college_course`
-- ----------------------------
DROP TABLE IF EXISTS `stu_college_course`;
CREATE TABLE `stu_college_course` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `majorId` varchar(50) NOT NULL COMMENT '专业id',
  `name` varchar(30) NOT NULL COMMENT '课程名称',
  `minutes` tinyint(4) NOT NULL DEFAULT '45' COMMENT '课时',
  `pptFileUrl` varchar(300) DEFAULT NULL COMMENT '课件地址',
  `gradeScore` tinyint(4) NOT NULL DEFAULT '0' COMMENT '课程成绩分数(0不需要考核,>0需要考核)',
  `remark` varchar(350) DEFAULT NULL COMMENT '备注',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='课程信息管理表';

-- ----------------------------
-- Records of stu_college_course
-- ----------------------------

-- ----------------------------
-- Table structure for `stu_college_course_notes`
-- ----------------------------
DROP TABLE IF EXISTS `stu_college_course_notes`;
CREATE TABLE `stu_college_course_notes` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `courseId` varchar(50) NOT NULL COMMENT '课程id',
  `userId` varchar(50) NOT NULL COMMENT '学生id',
  `noteContent` longtext NOT NULL COMMENT '笔记内容',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='课程笔记管理表';

-- ----------------------------
-- Records of stu_college_course_notes
-- ----------------------------

-- ----------------------------
-- Table structure for `stu_college_grade`
-- ----------------------------
DROP TABLE IF EXISTS `stu_college_grade`;
CREATE TABLE `stu_college_grade` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `majorId` varchar(50) NOT NULL COMMENT '专业id',
  `userId` varchar(50) NOT NULL COMMENT '学生id',
  `autoGradeScore` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '汇总成绩(根据算法自动求出)',
  `manualGradeScore` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '汇总成绩(人工录入，暂时不用)',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生成绩汇总管理表';

-- ----------------------------
-- Records of stu_college_grade
-- ----------------------------

-- ----------------------------
-- Table structure for `stu_college_major`
-- ----------------------------
DROP TABLE IF EXISTS `stu_college_major`;
CREATE TABLE `stu_college_major` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `parentId` varchar(50) NOT NULL DEFAULT '0000' COMMENT '父级id',
  `code` varchar(20) DEFAULT NULL COMMENT '标识码',
  `name` varchar(40) NOT NULL COMMENT '专业名称',
  `remark` varchar(250) NOT NULL COMMENT '备注',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学校专业管理表';

-- ----------------------------
-- Records of stu_college_major
-- ----------------------------

-- ----------------------------
-- Table structure for `stu_leave_record`
-- ----------------------------
DROP TABLE IF EXISTS `stu_leave_record`;
CREATE TABLE `stu_leave_record` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `userId` varchar(50) NOT NULL COMMENT '用户id',
  `typeId` varchar(50) NOT NULL COMMENT '请假类型--stu_leave_type.id',
  `url` varchar(300) DEFAULT NULL COMMENT '上传的请假条图片地址',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `auditEnum` tinyint(4) NOT NULL DEFAULT '10' COMMENT '审核状态：10待审核,20审核通过,30驳回',
  `auditRemark` varchar(350) DEFAULT NULL COMMENT '审核说明',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='请假记录表';

-- ----------------------------
-- Records of stu_leave_record
-- ----------------------------
INSERT INTO `stu_leave_record` VALUES ('2fe84842fbac4e519b35aba8def106a2', 'b5e59bd6e1da4098a28da61121e1d39b', 'ecf449e78f284f3c88ecb9c5fc1a0c29', null, '个人家庭原因，回家一趟，时间3天（2018.1.1－2018.1.3）', '30', '不批', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 19:01:10', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 19:25:30', '');
INSERT INTO `stu_leave_record` VALUES ('ea89c6da3a5448a38aea3adcc2acb6d8', 'b5e59bd6e1da4098a28da61121e1d39b', 'ecf449e78f284f3c88ecb9c5fc1a0c29', null, '小休息几天', '10', null, 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 19:29:47', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 19:29:47', '');

-- ----------------------------
-- Table structure for `stu_leave_type`
-- ----------------------------
DROP TABLE IF EXISTS `stu_leave_type`;
CREATE TABLE `stu_leave_type` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `code` varchar(20) DEFAULT NULL COMMENT '标识码',
  `name` varchar(30) NOT NULL COMMENT '参数名称',
  `remark` varchar(350) DEFAULT NULL COMMENT '备注',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='请假类型定义表';

-- ----------------------------
-- Records of stu_leave_type
-- ----------------------------
INSERT INTO `stu_leave_type` VALUES ('1f6dd69cd91a493fa26738df277eb83a', '110', '病假', '病假', '21232F297A57A5A743894A0E4A801FC3', '2017-12-31 18:27:44', '21232F297A57A5A743894A0E4A801FC3', '2017-12-31 18:27:44', '');
INSERT INTO `stu_leave_type` VALUES ('ecf449e78f284f3c88ecb9c5fc1a0c29', '100', '事假', '事假', '21232F297A57A5A743894A0E4A801FC3', '2017-12-31 18:27:07', '21232F297A57A5A743894A0E4A801FC3', '2017-12-31 18:27:51', '');

-- ----------------------------
-- Table structure for `stu_project`
-- ----------------------------
DROP TABLE IF EXISTS `stu_project`;
CREATE TABLE `stu_project` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `userId` varchar(50) NOT NULL COMMENT '学生id',
  `courseId` varchar(50) DEFAULT NULL COMMENT '项目所属课程id',
  `projectName` varchar(40) NOT NULL COMMENT '项目名称',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生项目管理表';

-- ----------------------------
-- Records of stu_project
-- ----------------------------

-- ----------------------------
-- Table structure for `stu_project2file`
-- ----------------------------
DROP TABLE IF EXISTS `stu_project2file`;
CREATE TABLE `stu_project2file` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `projectId` varchar(50) NOT NULL COMMENT '项目id-stu_project.id',
  `projectFileId` varchar(50) NOT NULL COMMENT '上传的文件id-stu_project_file.id',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生项目与上传文件关联表';

-- ----------------------------
-- Records of stu_project2file
-- ----------------------------

-- ----------------------------
-- Table structure for `stu_project_file`
-- ----------------------------
DROP TABLE IF EXISTS `stu_project_file`;
CREATE TABLE `stu_project_file` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `userId` varchar(50) NOT NULL COMMENT '学生id',
  `fileName` varchar(30) NOT NULL COMMENT '上传的文件名称',
  `fileUrl` varchar(300) NOT NULL COMMENT '上传的文件地址',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生上传的项目文件管理表';

-- ----------------------------
-- Records of stu_project_file
-- ----------------------------

-- ----------------------------
-- Table structure for `stu_resume`
-- ----------------------------
DROP TABLE IF EXISTS `stu_resume`;
CREATE TABLE `stu_resume` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `userId` varchar(50) NOT NULL COMMENT '学生id',
  `fileName` varchar(30) NOT NULL COMMENT '上传的简历文件名称',
  `fileUrl` varchar(300) NOT NULL COMMENT '文件的url地址',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生简历管理表';

-- ----------------------------
-- Records of stu_resume
-- ----------------------------

-- ----------------------------
-- Table structure for `system_config`
-- ----------------------------
DROP TABLE IF EXISTS `system_config`;
CREATE TABLE `system_config` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `code` varchar(20) DEFAULT NULL COMMENT '标识码',
  `name` varchar(30) NOT NULL COMMENT '参数名称',
  `remark` varchar(350) NOT NULL COMMENT '备注',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统参数配置信息表';

-- ----------------------------
-- Records of system_config
-- ----------------------------
INSERT INTO `system_config` VALUES ('09151cab7d544baba2e1d86ddbd61f66', 'copyright', '版权', 'MX工作室', '21232F297A57A5A743894A0E4A801FC3', '2017-12-30 20:36:22', '21232F297A57A5A743894A0E4A801FC3', '2017-12-30 20:36:22', '');
INSERT INTO `system_config` VALUES ('93099beaabb84b01b998182b725e82dc', 'systemName', '系统名称', 'NEW教务管理系统', '21232F297A57A5A743894A0E4A801FC3', '2017-12-30 20:34:05', '21232F297A57A5A743894A0E4A801FC3', '2017-12-30 20:34:05', '');
INSERT INTO `system_config` VALUES ('c3d9eba4eeb4406883547cfd4dfc9d87', 'test', '测试', '测试数据可删除', '21232F297A57A5A743894A0E4A801FC3', '2017-12-30 20:39:32', '21232F297A57A5A743894A0E4A801FC3', '2017-12-30 20:40:09', '');

-- ----------------------------
-- Table structure for `system_notification`
-- ----------------------------
DROP TABLE IF EXISTS `system_notification`;
CREATE TABLE `system_notification` (
  `id` varchar(50) NOT NULL COMMENT '主键',
  `userId` varchar(50) NOT NULL COMMENT '发布人id',
  `message` varchar(1000) NOT NULL COMMENT '公告内容',
  `openFlag` bit(1) NOT NULL DEFAULT b'1' COMMENT '开放状态：1开放，0不开放',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统公告表';

-- ----------------------------
-- Records of system_notification
-- ----------------------------
INSERT INTO `system_notification` VALUES ('5ab4cd2f282f4e6aaa4089b1d3ad83c9', '22528febe5224b428596260c3caa84d6', '好好学习，做一名合格的IT程序员', '', '22528febe5224b428596260c3caa84d6', '2017-12-31 16:29:33', '22528febe5224b428596260c3caa84d6', '2017-12-31 16:29:33', '');
INSERT INTO `system_notification` VALUES ('b1effa30aac245fd84a4d232c0823464', '21232F297A57A5A743894A0E4A801FC3', '新年好，新年到！老师们祝同学们在新的一年里好好学习，天天向上！', '', '21232F297A57A5A743894A0E4A801FC3', '2017-12-30 21:57:46', '22528febe5224b428596260c3caa84d6', '2017-12-31 16:04:16', '');
INSERT INTO `system_notification` VALUES ('b5f74ec03a1f479d9a7385e855e3864d', '21232F297A57A5A743894A0E4A801FC3', '2018年元旦放假3天，2017/12/30 2017/12/31 2018/01/01', '', '21232F297A57A5A743894A0E4A801FC3', '2017-12-30 20:44:26', '21232F297A57A5A743894A0E4A801FC3', '2017-12-30 20:44:26', '');

-- ----------------------------
-- Table structure for `system_user`
-- ----------------------------
DROP TABLE IF EXISTS `system_user`;
CREATE TABLE `system_user` (
  `id` varchar(50) NOT NULL DEFAULT '' COMMENT '主键',
  `code` varchar(15) DEFAULT NULL COMMENT '学号，工号',
  `password` varchar(50) NOT NULL DEFAULT 'E10ADC3949BA59ABBE56E057F20F883E' COMMENT '密码（加密处理，默认123456）',
  `autoPwdFlag` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否为自动生成的密码（1是，0否）',
  `name` varchar(20) NOT NULL COMMENT '姓名',
  `sex` bit(1) NOT NULL DEFAULT b'0' COMMENT '性别（0男，1女）',
  `birthday` date DEFAULT NULL COMMENT '出生日期',
  `phone` varchar(15) DEFAULT NULL COMMENT '手机号',
  `email` varchar(30) DEFAULT NULL COMMENT '邮箱',
  `qq` varchar(50) DEFAULT NULL COMMENT 'QQ号',
  `userType` tinyint(2) NOT NULL DEFAULT '1' COMMENT '用户类别：1学生，2老师，9管理员',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `createUser` varchar(50) DEFAULT NULL COMMENT '创建人id',
  `createDate` datetime DEFAULT NULL COMMENT '创建时间',
  `updateUser` varchar(50) DEFAULT NULL COMMENT '更新人id',
  `updateDate` datetime DEFAULT NULL COMMENT '更新时间',
  `deleteFlag` bit(1) NOT NULL DEFAULT b'0' COMMENT '逻辑删除：1删除，0未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户信息表';

-- ----------------------------
-- Records of system_user
-- ----------------------------
INSERT INTO `system_user` VALUES ('21232F297A57A5A743894A0E4A801FC3', 'admin', '21232f297a57a5a743894a0e4a801fc3', '', '系统管理员', '', null, null, null, null, '9', '密码为admin', null, null, null, null, '');
INSERT INTO `system_user` VALUES ('22528febe5224b428596260c3caa84d6', '1001', 'f379eaf3c831b04de153469d1bec345e', '', 'name001', '', '1979-12-20', null, '244277971@qq.com', '244277971', '2', '密码：666666', null, '2017-12-31 14:14:54', '22528febe5224b428596260c3caa84d6', '2017-12-31 16:08:59', '');
INSERT INTO `system_user` VALUES ('a4d86e267fe74100ba160e3845a05629', '2312', '5068f39a2477352f79b133af24d12232', '', 'name002', '', '1986-12-10', null, '244277971@qq.com', '244277971', '2', '密码：099644', null, '2017-12-31 14:19:28', null, '2017-12-31 14:19:28', '');
INSERT INTO `system_user` VALUES ('b5e59bd6e1da4098a28da61121e1d39b', '100000000001', 'e10adc3949ba59abbe56e057f20f883e', '', '小A', '', '1995-04-06', null, '244277971@qq.com', '214124141', '1', '密码：123456', null, '2017-12-31 16:33:35', 'b5e59bd6e1da4098a28da61121e1d39b', '2017-12-31 16:45:16', '');
