package com.edu.stu.course.bean.service.impl;

import org.apache.log4j.Logger;
import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.course.bean.CollegeGrade;
import com.edu.stu.course.bean.mapper.CollegeGradeMapper;
import com.edu.stu.course.bean.service.ICollegeGradeService;

public class CollegeGradeService extends JUIService<CollegeGrade, CollegeGradeMapper> implements ICollegeGradeService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeGradeService.class);

	public CollegeGradeService() {
		super(MybatisMutiKit.new_education_db, CollegeGradeMapper.class, CollegeGrade.class);
	}

}
