package com.base.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import com.jfinal.ext.kit.RandomCodeKit;
import com.jfinal.kit.HashKit;

public class TestPassword {

    private void loadProperties() throws IOException {
        Properties properties = new Properties();
        InputStream is = this.getClass().getClassLoader().getResourceAsStream("res/email");
        properties.load(new InputStreamReader(is, "UTF-8"));
    }
    
	//生成随机6位的密码字符串
	public static void main(String[] args) {

	}
}
