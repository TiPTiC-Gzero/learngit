package com.edu.stu.project.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.project.bean.Project;

public interface IProjectService extends IBaseService<Project> {

}
