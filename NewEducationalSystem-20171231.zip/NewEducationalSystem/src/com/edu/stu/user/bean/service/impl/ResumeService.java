package com.edu.stu.user.bean.service.impl;

import org.apache.log4j.Logger;
import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.user.bean.Resume;
import com.edu.stu.user.bean.mapper.ResumeMapper;
import com.edu.stu.user.bean.service.IResumeService;

public class ResumeService extends JUIService<Resume, ResumeMapper> implements IResumeService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(ResumeService.class);

	public ResumeService() {
		super(MybatisMutiKit.new_education_db, ResumeMapper.class, Resume.class);
	}

}
