package com.edu.stu.course.bean.mapper;

import com.edu.stu.course.bean.CollegeCourse;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface CollegeCourseMapper extends BaseSupportMapper {
}