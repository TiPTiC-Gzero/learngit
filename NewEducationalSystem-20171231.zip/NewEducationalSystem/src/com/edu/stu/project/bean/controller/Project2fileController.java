package com.edu.stu.project.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.project.bean.Project2file;
import com.edu.stu.project.bean.service.IProject2fileService;
import com.edu.stu.project.bean.service.impl.Project2fileService;

public class Project2fileController extends JUIServiceController<Project2file> {
	private static Logger logger = Logger.getLogger(Project2fileController.class);

	private static IProject2fileService project2fileService = new Project2fileService();

	public Project2fileController() {
		super(Project2file.class, project2fileService);
	}

}
