package com.base.kit;

import com.jfinal.db.mybatis.faces.IMybatisMapper;
import com.jfinal.db.mybatis.kit.MybatisKit;

public class MybatisMutiKit {
	
	//访问new_education_db
	public static IMybatisMapper new_education_db = use("new_education_db");
	
	private static IMybatisMapper use(String name) {
		//MybatisKit.starts(ConfigFileKit.config_mybatis, "new_education_db");
		return MybatisKit.use(name);
	}
	
}
