package com.edu.stu.user.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.user.bean.Resume;
import com.edu.stu.user.bean.service.IResumeService;
import com.edu.stu.user.bean.service.impl.ResumeService;

public class ResumeController extends JUIServiceController<Resume> {
	private static Logger logger = Logger.getLogger(ResumeController.class);

	private static IResumeService resumeService = new ResumeService();

	public ResumeController() {
		super(Resume.class, resumeService);
	}

}
