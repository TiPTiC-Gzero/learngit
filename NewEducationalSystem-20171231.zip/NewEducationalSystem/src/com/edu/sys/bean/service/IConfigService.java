package com.edu.sys.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.sys.bean.Config;

public interface IConfigService extends IBaseService<Config> {

}
