package com.edu.stu.atten.bean.service.impl;

import java.util.Date;

import org.apache.log4j.Logger;

import com.base.kit.MybatisMutiKit;
import com.edu.stu.atten.bean.AttendanceRecordHead;
import com.edu.stu.atten.bean.mapper.AttendanceRecordHeadMapper;
import com.edu.stu.atten.bean.service.IAttendanceRecordHeadService;
import com.jfinal.jui.JUIService;
import com.jfinal.kit.JsonKit;

public class AttendanceRecordHeadService extends JUIService<AttendanceRecordHead, AttendanceRecordHeadMapper> implements IAttendanceRecordHeadService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(AttendanceRecordHeadService.class);

	public AttendanceRecordHeadService() {
		super(MybatisMutiKit.new_education_db, AttendanceRecordHeadMapper.class, AttendanceRecordHead.class);
	}

	@Override
	public AttendanceRecordHead getAttendanceRecordHead(String userId, Date attDate) {
		AttendanceRecordHead record = new AttendanceRecordHead();
		record.setAttDate(attDate);
		record.setUserId(userId);
		logger.debug("AttendanceRecordHead record = "+JsonKit.toJson(record));
		AttendanceRecordHead bean = MybatisMutiKit.new_education_db.selectOne(clazzM, record);
		logger.debug("AttendanceRecordHead bean = "+JsonKit.toJson(bean));
		return bean;
	}

}
