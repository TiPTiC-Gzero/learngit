package com.edu.stu.course.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.course.bean.CollegeCourse;
import com.edu.stu.course.bean.service.ICollegeCourseService;
import com.edu.stu.course.bean.service.impl.CollegeCourseService;

public class CollegeCourseController extends JUIServiceController<CollegeCourse> {
	private static Logger logger = Logger.getLogger(CollegeCourseController.class);

	private static ICollegeCourseService collegeCourseService = new CollegeCourseService();

	public CollegeCourseController() {
		super(CollegeCourse.class, collegeCourseService);
	}

}
