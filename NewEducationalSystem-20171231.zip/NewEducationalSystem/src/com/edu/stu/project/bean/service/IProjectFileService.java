package com.edu.stu.project.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.project.bean.ProjectFile;

public interface IProjectFileService extends IBaseService<ProjectFile> {

}
