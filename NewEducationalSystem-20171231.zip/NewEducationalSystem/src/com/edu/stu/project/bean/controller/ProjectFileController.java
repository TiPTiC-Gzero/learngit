package com.edu.stu.project.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.project.bean.ProjectFile;
import com.edu.stu.project.bean.service.IProjectFileService;
import com.edu.stu.project.bean.service.impl.ProjectFileService;

public class ProjectFileController extends JUIServiceController<ProjectFile> {
	private static Logger logger = Logger.getLogger(ProjectFileController.class);

	private static IProjectFileService projectFileService = new ProjectFileService();

	public ProjectFileController() {
		super(ProjectFile.class, projectFileService);
	}

}
