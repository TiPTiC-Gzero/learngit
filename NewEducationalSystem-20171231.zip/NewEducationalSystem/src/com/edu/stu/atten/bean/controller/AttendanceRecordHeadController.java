package com.edu.stu.atten.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.atten.bean.AttendanceRecordHead;
import com.edu.stu.atten.bean.service.IAttendanceRecordHeadService;
import com.edu.stu.atten.bean.service.impl.AttendanceRecordHeadService;

public class AttendanceRecordHeadController extends JUIServiceController<AttendanceRecordHead> {
	private static Logger logger = Logger.getLogger(AttendanceRecordHeadController.class);

	private static IAttendanceRecordHeadService attendanceRecordHeadService = new AttendanceRecordHeadService();

	public AttendanceRecordHeadController() {
		super(AttendanceRecordHead.class, attendanceRecordHeadService);
	}

}
