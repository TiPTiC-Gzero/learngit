package com.edu.sys.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.sys.bean.Config;
import com.edu.sys.bean.service.IConfigService;
import com.edu.sys.bean.service.impl.ConfigService;

public class ConfigController extends JUIServiceController<Config> {
	private static Logger logger = Logger.getLogger(ConfigController.class);

	private static IConfigService configService = new ConfigService();

	public ConfigController() {
		super(Config.class, configService);
	}

}
