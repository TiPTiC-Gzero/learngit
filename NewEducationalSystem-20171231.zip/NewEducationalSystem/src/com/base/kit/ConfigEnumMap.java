package com.base.kit;

import java.util.Map;

import com.jfinal.json.FastJson;
import com.jfinal.kit.PropKit;

public class ConfigEnumMap extends ConfigFileKit {

	@SuppressWarnings("unchecked")
	public static Map<Integer, String> statusEnumMap = FastJson.getJson().parse(PropKit.get("statusEnumMap"), Map.class);
	
	public static void main(String[] args) {
		System.out.println(statusEnumMap);
	}
}
