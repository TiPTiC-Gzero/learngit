package com.edu.stu.course.bean.service.impl;

import org.apache.log4j.Logger;
import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.course.bean.CollegeCourseNotes;
import com.edu.stu.course.bean.mapper.CollegeCourseNotesMapper;
import com.edu.stu.course.bean.service.ICollegeCourseNotesService;

public class CollegeCourseNotesService extends JUIService<CollegeCourseNotes, CollegeCourseNotesMapper> implements ICollegeCourseNotesService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(CollegeCourseNotesService.class);

	public CollegeCourseNotesService() {
		super(MybatisMutiKit.new_education_db, CollegeCourseNotesMapper.class, CollegeCourseNotes.class);
	}

}
