package com.edu.stu.user.bean.mapper;

import com.edu.stu.user.bean.User;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface UserMapper extends BaseSupportMapper {
}