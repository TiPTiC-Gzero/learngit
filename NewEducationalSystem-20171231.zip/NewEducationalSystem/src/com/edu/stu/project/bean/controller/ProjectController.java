package com.edu.stu.project.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.project.bean.Project;
import com.edu.stu.project.bean.service.IProjectService;
import com.edu.stu.project.bean.service.impl.ProjectService;

public class ProjectController extends JUIServiceController<Project> {
	private static Logger logger = Logger.getLogger(ProjectController.class);

	private static IProjectService projectService = new ProjectService();

	public ProjectController() {
		super(Project.class, projectService);
	}

}
