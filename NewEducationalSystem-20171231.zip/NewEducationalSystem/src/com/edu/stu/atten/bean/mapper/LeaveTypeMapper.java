package com.edu.stu.atten.bean.mapper;

import com.edu.stu.atten.bean.LeaveType;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface LeaveTypeMapper extends BaseSupportMapper {
}