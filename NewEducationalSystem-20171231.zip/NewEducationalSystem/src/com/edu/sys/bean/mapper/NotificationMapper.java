package com.edu.sys.bean.mapper;

import com.edu.sys.bean.Notification;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface NotificationMapper extends BaseSupportMapper {
}