package com.edu.stu.course.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.course.bean.CollegeCourse;

public interface ICollegeCourseService extends IBaseService<CollegeCourse> {

}
