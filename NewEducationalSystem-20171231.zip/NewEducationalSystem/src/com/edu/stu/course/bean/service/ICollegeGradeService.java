package com.edu.stu.course.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.course.bean.CollegeGrade;

public interface ICollegeGradeService extends IBaseService<CollegeGrade> {

}
