package com.edu.stu.atten.bean.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.edu.stu.atten.bean.LeaveRecord;
import com.edu.stu.atten.bean.LeaveType;
import com.edu.stu.atten.bean.service.ILeaveRecordService;
import com.edu.stu.atten.bean.service.ILeaveTypeService;
import com.edu.stu.atten.bean.service.impl.LeaveRecordService;
import com.edu.stu.atten.bean.service.impl.LeaveTypeService;
import com.jfinal.jui.JUIServiceController;
import com.jfinal.jui.constants.PageConstants;
import com.jfinal.kit.JsonKit;
import com.jfinal.kit.StrKit;

public class LeaveRecordController extends JUIServiceController<LeaveRecord> {
	private static Logger logger = Logger.getLogger(LeaveRecordController.class);

	private static ILeaveRecordService leaveRecordService = new LeaveRecordService();
	private static ILeaveTypeService leaveTypeService = new LeaveTypeService();
	
	public LeaveRecordController() {
		super(LeaveRecord.class, leaveRecordService);
	}
	
	@Override
	public void add() {
		List<LeaveType> leaveTypeList = leaveTypeService.getLeaveTypeList();
		setAttr("leaveTypeList", leaveTypeList);
		super.add();
	}

	@Override
	public void view() {
		String id = getId();
		if(StrKit.isBlank(id)){
			renderJson(this.ajaxError("can not find param id!"));
			return;
		}else{
			logger.info("id = "+id);
			Map<String, Object> example = new HashMap<String, Object>();
			example.put("id", id);
			Map<String, Object> bean = this.baseService.getMapByExample(example);
			logger.info("bean = "+JsonKit.toJson(bean));
			setAttr(PageConstants.ModelName, bean);
		}
	}
}
