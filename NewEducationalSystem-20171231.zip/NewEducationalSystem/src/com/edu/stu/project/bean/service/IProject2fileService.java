package com.edu.stu.project.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.project.bean.Project2file;

public interface IProject2fileService extends IBaseService<Project2file> {

}
