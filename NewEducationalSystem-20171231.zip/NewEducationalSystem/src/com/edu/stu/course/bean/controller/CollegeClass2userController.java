package com.edu.stu.course.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.course.bean.CollegeClass2user;
import com.edu.stu.course.bean.service.ICollegeClass2userService;
import com.edu.stu.course.bean.service.impl.CollegeClass2userService;

public class CollegeClass2userController extends JUIServiceController<CollegeClass2user> {
	private static Logger logger = Logger.getLogger(CollegeClass2userController.class);

	private static ICollegeClass2userService collegeClass2userService = new CollegeClass2userService();

	public CollegeClass2userController() {
		super(CollegeClass2user.class, collegeClass2userService);
	}

}
