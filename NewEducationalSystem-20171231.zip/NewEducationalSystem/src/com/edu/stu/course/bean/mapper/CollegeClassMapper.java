package com.edu.stu.course.bean.mapper;

import com.edu.stu.course.bean.CollegeClass;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface CollegeClassMapper extends BaseSupportMapper {
}