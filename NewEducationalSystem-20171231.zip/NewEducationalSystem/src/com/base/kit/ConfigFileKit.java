package com.base.kit;

import com.jfinal.kit.Prop;
import com.jfinal.kit.PropKit;

/**
 * 读取配置文件帮助类
 * @author mengxin 2016年11月22日 上午11:58:59
 */
public class ConfigFileKit {
	
	public static final String CONFIG_FILE = "res/config.properties";
	
	public static String ENV = PropKit.use(ConfigFileKit.CONFIG_FILE).get("base.environment");
	
	public static String config_mybatis = PropKit.get("mybatis."+ENV+".config");
	
	public static Prop porp_jdbc = PropKit.use("res/jdbc/jdbc.properties");

	public static String generated_source_dir = PropKit.get("generated."+ENV+".dir");

}
