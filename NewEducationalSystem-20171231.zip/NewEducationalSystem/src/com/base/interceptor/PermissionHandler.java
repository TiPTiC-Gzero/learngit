package com.base.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.base.controller.IndexController;
import com.edu.stu.user.bean.User;
import com.jfinal.handler.Handler;
import com.jfinal.jui.constants.SessionConstants;

/**
 * 过滤页面
 * 只允许直接访问login.jsp页面，其它页面必须验证登录才能访问
 * @author mengxin 2016年7月9日 下午6:07:58
 */
public class PermissionHandler extends Handler{
	private static Logger logger = Logger.getLogger(PermissionHandler.class);
	
	@Override
	public void handle(String target, HttpServletRequest request,HttpServletResponse response, boolean[] isHandled) {
        //只允许直接访问登录页面，其它页面必须验证登录才能访问
		boolean isPage = target.lastIndexOf(".jsp")!=-1 || target.lastIndexOf(".html")!=-1 || target.lastIndexOf(".htm")!=-1;
		boolean isLoginPage = target.contains(IndexController.Page_login);
        if (isPage && !isLoginPage) {
			logger.debug("start handle target="+target);
			// 这里写拦截器相应的处理逻辑
            HttpSession session = request.getSession(true);
            
            User userBean = null;
            Object user = session.getAttribute("user");
            if(user!=null){
            	userBean = (User) session.getAttribute("user");
            }
            
            if(session==null || session.getAttribute(SessionConstants.USER_ID)==null){              
            	logger.warn("no login, redirect to login.jsp");
                target="/index";//方式一：跳转访问IndexController.index()进入跳转到登录页面
            }else if(target.contains(IndexController.Page_Manage)){
            	//如果访问的是管理员界面
        		if(userBean==null){
        			target="/index";
        		}else{
            		Byte type = userBean.getUserType();
            		if(type==null || type!=9){
            			logger.warn("不是管理员，无权访问！");
            			request.setAttribute("page_error", "不是管理员，无权访问！");
            			
        				session.removeAttribute("user");
        				session.removeAttribute(SessionConstants.USER_ID);
            			target="/index";
            		}
        		}
            }else if(target.contains(IndexController.Page_Teacher)){
            	//如果访问的是老师界面
        		if(userBean==null){
        			target="/index";
        		}else{
            		Byte type = userBean.getUserType();
            		if(type==null || type!=2){
            			logger.warn("不是老师，无权访问！");
            			request.setAttribute("page_error", "不是老师，无权访问！");
            			
        				session.removeAttribute("user");
        				session.removeAttribute(SessionConstants.USER_ID);
            			target="/index";
            		}
        		}
            }else if(target.contains(IndexController.Page_Student)){
            	//如果访问的是学生界面
        		if(userBean==null){
        			target="/index";
        		}else{
            		Byte type = userBean.getUserType();
            		if(type==null || type!=1){
            			logger.warn("不是学生，无权访问！");
            			request.setAttribute("page_error", "不是学生，无权访问！");
            			
        				session.removeAttribute("user");
        				session.removeAttribute(SessionConstants.USER_ID);
            			target="/index";
            		}
        		}
            }
			logger.debug("stop handle target="+target);
		}
		next.handle(target, request, response, isHandled);  //JFinal中next已经取代了nextHandler。
	}
	
}
