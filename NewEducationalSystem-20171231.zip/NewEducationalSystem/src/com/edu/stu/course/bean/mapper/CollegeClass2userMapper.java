package com.edu.stu.course.bean.mapper;

import com.edu.stu.course.bean.CollegeClass2user;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface CollegeClass2userMapper extends BaseSupportMapper {
}