package com.edu.stu.course.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.course.bean.CollegeGrade;
import com.edu.stu.course.bean.service.ICollegeGradeService;
import com.edu.stu.course.bean.service.impl.CollegeGradeService;

public class CollegeGradeController extends JUIServiceController<CollegeGrade> {
	private static Logger logger = Logger.getLogger(CollegeGradeController.class);

	private static ICollegeGradeService collegeGradeService = new CollegeGradeService();

	public CollegeGradeController() {
		super(CollegeGrade.class, collegeGradeService);
	}

}
