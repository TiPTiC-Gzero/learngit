package com.edu.stu.atten.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.atten.bean.LeaveRecord;

public interface ILeaveRecordService extends IBaseService<LeaveRecord> {

}
