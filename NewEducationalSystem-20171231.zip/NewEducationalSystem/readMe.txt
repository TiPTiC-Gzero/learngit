
访问入口 http://localhost/NewEducationalSystem/

######使用说明：
		执行数据库文件：sql/new_education_db-20171231.sql
		修改数据库连接参数（jdbc.user及jdbc.password）：src/res/mybatis127.xml
	<properties>
		<property name="jdbc.url.new_education_db" value="jdbc:mysql://127.0.0.1:3306/new_education_db?characterEncoding=utf8&amp;zeroDateTimeBehavior=convertToNull"/>
		<property name="jdbc.user" value="root"/>
		<property name="jdbc.password" value="root"/>
	</properties>
	
开发进度：
########## 2017/12/30 ##########
完成数据库表设计：共计17张表；
完成数据库表文档；

########## 2017/12/31 ##########
完成系统管理
	－－－系统参数管理
	－－－系统公告管理
	－－－用户管理（默认管理员 admin/admin）
	－－－系统菜单、角色管理（不同的用户登录进行不同后台jsp页面）
	
完成登录功能
完成注册功能（发邮件暂未实现）
完成重置密码功能

$$$$学生管理－－－学生档案管理（需求不明确，档案有哪些属性未说明，暂不实现）

完成考勤管理功能
	－－－考勤打卡
	－－－请假类型管理
	－－－请假管理（上传请假图片暂未实现）
	
########## 2018/01/01 ##########


########## 2017/01/02 ##########


########## 2017/01/03 ##########