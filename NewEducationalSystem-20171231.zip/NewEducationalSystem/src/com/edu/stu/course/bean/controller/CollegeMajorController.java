package com.edu.stu.course.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.course.bean.CollegeMajor;
import com.edu.stu.course.bean.service.ICollegeMajorService;
import com.edu.stu.course.bean.service.impl.CollegeMajorService;

public class CollegeMajorController extends JUIServiceController<CollegeMajor> {
	private static Logger logger = Logger.getLogger(CollegeMajorController.class);

	private static ICollegeMajorService collegeMajorService = new CollegeMajorService();

	public CollegeMajorController() {
		super(CollegeMajor.class, collegeMajorService);
	}

}
