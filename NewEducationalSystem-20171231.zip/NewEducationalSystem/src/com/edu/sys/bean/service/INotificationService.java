package com.edu.sys.bean.service;

import java.util.List;
import java.util.Map;

import com.jfinal.jui.IBaseService;
import com.edu.sys.bean.Notification;

public interface INotificationService extends IBaseService<Notification> {

	//获取最近一周的公告信息
	public List<Map<String, Object>> getOneWeekContentList();
}
