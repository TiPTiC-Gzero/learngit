package com.base.interceptor;

import org.apache.log4j.Logger;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;
import com.jfinal.jui.constants.SessionConstants;
import com.jfinal.kit.StrKit;

/**
 * 拦截器，拦截非法登录
 */
public class LoginActionInterceptor implements Interceptor {
	private static Logger logger = Logger.getLogger(LoginActionInterceptor.class);

	@Override
	public void intercept(Invocation inv) {
		Controller controller = inv.getController();
		String actionKey = inv.getActionKey();
		logger.info("actionKey : "+actionKey);

		//只拦截非指定的请求!actionKey.endsWith("/") && 
		
		if (!actionKey.endsWith("/login") && !actionKey.endsWith("/logout") 
				&& !actionKey.endsWith("/register") 
				&& !actionKey.endsWith("/User/add")  && !actionKey.endsWith("/User/save")) {
			String uid = controller.getSessionAttr(SessionConstants.USER_ID);
			logger.info("session uid : "+uid);
			if (StrKit.isBlank(uid)) {
				controller.redirect("/login.jsp");
				return;
			}
		}
		inv.invoke();
	}
	 
}
