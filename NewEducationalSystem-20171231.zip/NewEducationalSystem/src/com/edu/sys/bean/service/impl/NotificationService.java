package com.edu.sys.bean.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.sys.bean.Notification;
import com.edu.sys.bean.mapper.NotificationMapper;
import com.edu.sys.bean.service.INotificationService;

public class NotificationService extends JUIService<Notification, NotificationMapper> implements INotificationService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(NotificationService.class);

	public NotificationService() {
		super(MybatisMutiKit.new_education_db, NotificationMapper.class, Notification.class);
	}

	@Override
	public List<Map<String, Object>> getOneWeekContentList() {
		Map<String, Object> example = new HashMap<>();
		example.put("interface", "getOneWeekContentList");
		logger.debug(example);
		List<Map<String, Object>> dataList = MybatisMutiKit.new_education_db.selectListColumnsByInterface(clazzM, example);
		logger.debug(dataList);
		return dataList;
	}

}
