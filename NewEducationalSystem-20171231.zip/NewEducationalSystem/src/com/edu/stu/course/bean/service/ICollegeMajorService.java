package com.edu.stu.course.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.course.bean.CollegeMajor;

public interface ICollegeMajorService extends IBaseService<CollegeMajor> {

}
