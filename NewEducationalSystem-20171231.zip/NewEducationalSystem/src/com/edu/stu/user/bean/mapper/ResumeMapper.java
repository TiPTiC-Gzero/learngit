package com.edu.stu.user.bean.mapper;

import com.edu.stu.user.bean.Resume;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface ResumeMapper extends BaseSupportMapper {
}