package com.base.controller;

import org.apache.log4j.Logger;

import com.edu.stu.user.bean.User;
import com.edu.stu.user.bean.service.IUserService;
import com.edu.stu.user.bean.service.impl.UserService;
import com.jfinal.core.Controller;
import com.jfinal.jui.constants.SessionConstants;
import com.jfinal.kit.StrKit;

public class IndexController extends Controller {
	private static Logger logger = Logger.getLogger(IndexController.class);

	public static String Page_login = "/login.jsp";
	public static String Page_register = "/register.jsp";
	public static String Page_Manage = "/manage.jsp";
	public static String Page_Teacher = "/teacher.jsp";
	public static String Page_Student = "/student.jsp";
	
	private IUserService userService = new UserService();

	/**
	 * http://local.ixingtu.com/NewEducationalSystem
	 *@Description: 访问进入index.jsp
	 *@return_type void
	 */
	public void index() {
		String uid = getSessionAttr(SessionConstants.USER_ID);
		if(StrKit.isBlank(uid)){
			redirect(Page_login);
			return;
		}
	}
	
	/**
	 * http://local.ixingtu.com/NewEducationalSystem/manage
	 *@Description: 访问进入manage.jsp
	 *@return_type void
	 */
	public void manage() {
	}

	/**
	 * http://local.ixingtu.com/NewEducationalSystem/register
	 *@Description: 访问进入register.jsp
	 */
	public void register() {
	}
	
	/**
	 * http://local.ixingtu.com/NewEducationalSystem/login
	 *@Description: 访问进入login.jsp
	 */
	public void login() {
		String userName = getPara("userName");
		String passWord = getPara("passWord");
		User bean = null;
		try {
			bean = userService.getUser(userName, passWord);
		} catch (Exception e) {
			logger.error(e.getMessage());
			setAttr("page_error", e.getMessage());
			redirect(Page_login);
		}
		
		if(bean != null){
			getSession().setMaxInactiveInterval(60*60*1); //过期时间为一天
			setSessionAttr(SessionConstants.USER_ID, bean.getId());
			
			//设置用户对象
			setSessionAttr("userName", userName);
			setSessionAttr("user", bean);

			//用户类型：1学生，2老师，9管理员
			Byte type = bean.getUserType();
			if(type==9){
				redirect(Page_Manage);
				return;
			}else if(type==2){
				redirect(Page_Teacher);
				return;
			}else{
				redirect(Page_Student);
				return;
			}
		}else{
			setAttr("page_error", "账号或密码错误！");
			render(Page_login);
		}
	}
	
	/**
	 * 退出
	 * @return
	 */
	public void logout() {
		removeSessionAttr(SessionConstants.USER_ID);
		removeSessionAttr("user");
		logger.info(getSessionAttr("userName")+" logout success....");
		redirect(Page_login);
	}
}
