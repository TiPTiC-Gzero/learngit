package com.edu.stu.user.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.user.bean.Resume;

public interface IResumeService extends IBaseService<Resume> {

}
