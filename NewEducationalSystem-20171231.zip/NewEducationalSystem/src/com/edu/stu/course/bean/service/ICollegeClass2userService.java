package com.edu.stu.course.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.course.bean.CollegeClass2user;

public interface ICollegeClass2userService extends IBaseService<CollegeClass2user> {

}
