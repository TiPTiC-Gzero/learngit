package com.edu.stu.course.bean.controller;

import org.apache.log4j.Logger;

import com.jfinal.jui.JUIServiceController;
import com.edu.stu.course.bean.CollegeClass;
import com.edu.stu.course.bean.service.ICollegeClassService;
import com.edu.stu.course.bean.service.impl.CollegeClassService;

public class CollegeClassController extends JUIServiceController<CollegeClass> {
	private static Logger logger = Logger.getLogger(CollegeClassController.class);

	private static ICollegeClassService collegeClassService = new CollegeClassService();

	public CollegeClassController() {
		super(CollegeClass.class, collegeClassService);
	}

}
