package com.edu.stu.project.bean.service.impl;

import org.apache.log4j.Logger;
import com.base.kit.MybatisMutiKit;
import com.jfinal.jui.JUIService;
import com.edu.stu.project.bean.ProjectFile;
import com.edu.stu.project.bean.mapper.ProjectFileMapper;
import com.edu.stu.project.bean.service.IProjectFileService;

public class ProjectFileService extends JUIService<ProjectFile, ProjectFileMapper> implements IProjectFileService {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(ProjectFileService.class);

	public ProjectFileService() {
		super(MybatisMutiKit.new_education_db, ProjectFileMapper.class, ProjectFile.class);
	}

}
