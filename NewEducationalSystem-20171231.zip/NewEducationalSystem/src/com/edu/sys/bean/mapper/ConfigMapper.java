package com.edu.sys.bean.mapper;

import com.edu.sys.bean.Config;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface ConfigMapper extends BaseSupportMapper {
}