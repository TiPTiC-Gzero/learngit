package com.edu.stu.user.bean.service;

import com.jfinal.jui.IBaseService;
import com.edu.stu.user.bean.User;

public interface IUserService extends IBaseService<User> {

	//根据用户名密码获取User对象
	public User getUser(String userName, String passWord) throws Exception;
}
