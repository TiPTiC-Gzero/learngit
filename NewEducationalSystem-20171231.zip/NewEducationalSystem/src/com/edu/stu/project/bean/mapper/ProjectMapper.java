package com.edu.stu.project.bean.mapper;

import com.edu.stu.project.bean.Project;
import com.jfinal.db.mybatis.faces.BaseSupportMapper;

public interface ProjectMapper extends BaseSupportMapper {
}